package com.example.query

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
